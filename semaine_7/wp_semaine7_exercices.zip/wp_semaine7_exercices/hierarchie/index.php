<?php get_header(); ?>

<h1>Gabarit index.php</h1>

<?php if( have_posts() ) : ?>
<?php while (have_posts()) : the_post(); ?>
	<article <?php post_class(); ?> id="post-<?php the_ID();?>">
		<h3><?php the_title(); ?></h3>
		<?php the_post_thumbnail('medium'); ?>
		---- SOMMAIRE ----
		<?php the_excerpt(); ?>
		---- CONTENU ----
		<?php the_content(); ?>
		<a href="<?php the_permalink(); ?>" class="morelink">
		Suite&hellip;</a>
	</article>
<?php endwhile; ?>
<?php endif; ?>