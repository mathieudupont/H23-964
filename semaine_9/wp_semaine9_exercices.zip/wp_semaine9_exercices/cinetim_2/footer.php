        <footer class="footer">
            <div class="wrap">
                <?php bloginfo('name') ?> &copy; <?php echo date("Y"); ?> - Tous droits réservés !
            </div>
        </footer>

        <?php wp_footer(); ?>
        <script src="<?php bloginfo('template_url') ?>/assets/script.js"></script>
    </body>
</html>