<?php get_header(); ?>


<section class="hero">
    <div class="wrap">
        <div class="hero__medias">
            <div class="hero__poster">
                <img src="<?php echo bloginfo('template_url'); ?>/assets/affiche.jpg" alt="">
            </div>
            <div class="hero__image">
                <img src="<?php echo bloginfo('template_url'); ?>/assets/capture.jpg" alt="">
            </div>
        </div>
    </div>
</section>

<section class="grid section wrap">
    <h1 class="grid__title">
        Mon film
    </h1>
    <div class="grid__content o-typography">
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Doloremque, velit dolores iste nobis necessitatibus et quis accusantium ea quibusdam omnis odio reprehenderit laboriosam voluptatum aliquid perspiciatis sapiente illum commodi. Ipsa.</p>

        <h2>Acteurs</h2>
        <ul>
            <li>Bernard Leblanc</li>
            <li>Jean-François Imbert</li>
            <li>J'imbert Lebernard dit l'hermite</li>
        </ul>
    </div>
    <div class="grid__sidebar o-typography">
        <h3>Ma note</h3>
        <p>
            5
            ⭐
        </p>

        <h3>Réalisateur</h3>
        <p>Jean Leblond</p>
        
        <h3>Date de sortie</h3>
        <p><?php echo get_the_date(); ?></p>

        <h3>Genre</h3>
        <?php $categories = array(); ?>
        <?php foreach( get_the_category() as $category ): ?>
            <?php array_push($categories, $category->name); ?>
        <?php endforeach?>
        <p><?php echo implode(', ', $categories); ?></p>
    </div>
</section>


<?php get_footer(); ?>