        <footer class="footer">
            <div class="wrap">
                <?php bloginfo('name') ?> &copy; <?php echo date("Y"); ?> - Tous droits réservés !

                <a class="button button--invert" href="mailto:<?php echo the_field('cw4_courriel_contact', 'option'); ?>">
                        Écrivez-nous
                </a>

                <?php if ( have_rows('cw4_sociaux', 'option') ): ?>
                    <ul class="social">
                        <?php while( have_rows('cw4_sociaux', 'option') ): the_row(); ?>
                            <?php if ( get_sub_field('type') === 'LinkedIn' ) : ?>
                                <li><a href="<?php the_sub_field('url'); ?>" target="_blank">
                                        <i class="fab fa-linkedin-in"></i>
                                    </a></li>
                            <?php elseif ( get_sub_field('type') === 'Instagram') : ?>
                                <li><a href="<?php the_sub_field('url'); ?>" target="_blank">
                                        <i class="fab fa-instagram"></i>
                                    </a></li>
                            <?php elseif ( get_sub_field('type') === 'Facebook') : ?>
                                <li><a href="<?php the_sub_field('url'); ?>" target="_blank">
                                        <i class="fab fa-facebook-f"></i>
                                    </a></li>
                            <?php elseif ( get_sub_field('type') === 'Twitter') : ?>
                                <li><a href="<?php the_sub_field('url'); ?>" target="_blank">
                                        <i class="fab fa-twitter"></i>
                                    </a></li>
                            <?php endif; ?>
                        <?php endwhile; ?>
                    </ul>
                <?php endif; ?>

            </div>
        </footer>

        <?php wp_footer(); ?>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/Swiper/5.3.8/js/swiper.min.js"></script>
        <script src="<?php bloginfo('template_url') ?>/assets/script.js"></script>
    </body>
</html>