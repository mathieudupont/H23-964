        <footer class="footer">
            <div class="wrap">
                <?php bloginfo('name') ?> &copy; <?php echo date("Y"); ?> - Tous droits réservés !

                <a class="button button--invert" href="mailto:mon@adresse.com">
                    Écrivez-nous
                </a>
                
                <ul class="social">
                    <li><a href="#" target="_blank">
                        <i class="fab fa-linkedin-in"></i>
                    </a></li>
                    <li><a href="#" target="_blank">
                        <i class="fab fa-instagram"></i>
                    </a></li>
                    <li><a href="#" target="_blank">
                        <i class="fab fa-facebook-f"></i>
                    </a></li>
                    <li><a href="#" target="_blank">
                        <i class="fab fa-twitter"></i>
                    </a></li>
                </ul>

            </div>
        </footer>

        <?php wp_footer(); ?>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/Swiper/5.3.8/js/swiper.min.js"></script>
        <script src="<?php bloginfo('template_url') ?>/assets/script.js"></script>
    </body>
</html>